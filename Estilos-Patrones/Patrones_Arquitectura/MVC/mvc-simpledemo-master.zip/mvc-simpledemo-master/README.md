mvc-simpledemo
==============

Ejemplo de una aplicación sencilla utilizando [Asp.Net MVC](http://www.asp.net/mvc) versión 5.

> **Nota**: Este repositorio es únicamente de ejemplo por lo que no se aplican las mejores practicas de desarrollo .Net ni Mvc. el único propósito es servir de referencia para que un developer junior tenga su primer acercamiento a Mvc5.

Para ver la evolución del proyecto y como se ha ido desarrollando puedes ver el [historial de commits](https://github.com/miguelerm/mvc-simpledemo/commits/master)
